/*
 *
 * Dashboard constants
 *
 */

export const TOGGLE_DASHBOARD_MENU = 'src/Dashboard/TOGGLE_DASHBOARD_MENU';
